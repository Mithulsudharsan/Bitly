import unittest
from src.main import extract_hash

class TestMain(unittest.TestCase):
    def test_extract_hash(self):
        self.assertEqual(extract_hash("http://bit.ly/abc123"), "abc123")

if __name__ == '__main__':
    unittest.main()
